﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace De_tai
{
    public partial class Form1 : Form
    {
        Entities1 dbe = new Entities1();
        public Form1()
        {
            InitializeComponent();
            LoadData();
        }
        void LoadData()
        {
            var listNV = from nv in dbe.NHANVIENs select new { MaNV = nv.MaNV, HoTen = nv.HoTen, NgaySinh = nv.NgaySinh, DiaChi = nv.DiaChi, TenPB = nv.PHONGBAN.TenPB, TenCV = nv.CHUC_VU.TenCV };
            DGVNhanVien.DataSource = listNV.ToList();
            txtHoTen.DataBindings.Clear();
            txtHoTen.DataBindings.Add(new Binding("Text", DGVNhanVien.DataSource, "HoTen"));
            txtMaNV.DataBindings.Clear();
            txtMaNV.DataBindings.Add(new Binding("Text", DGVNhanVien.DataSource, "MaNV"));
            txtDiaChi.DataBindings.Clear();
            txtDiaChi.DataBindings.Add(new Binding("Text", DGVNhanVien.DataSource, "DiaChi"));
            CBPhongBan.DataSource = dbe.PHONGBANs.ToList();
            CBPhongBan.DisplayMember = "TenPB";
            CBPhongBan.DataBindings.Clear();
            CBPhongBan.DataBindings.Add(new Binding("Text", DGVNhanVien.DataSource, "TenPB"));
            CBChucVu.DataSource = dbe.CHUC_VU.ToList();
            CBChucVu.DisplayMember = "TenCV";
            CBChucVu.DataBindings.Clear();
            CBChucVu.DataBindings.Add(new Binding("Text", DGVNhanVien.DataSource, "TenCV"));
            DTPNgaySinh.DataBindings.Clear();
            DTPNgaySinh.DataBindings.Add(new Binding("Text", DGVNhanVien.DataSource, "NgaySinh"));
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            var DR = MessageBox.Show("Bạn có muốn thoát khỏi chương trình không ?", "Cảnh báo", MessageBoxButtons.YesNo);
            if (DR == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void btnAdd1_Click(object sender, EventArgs e)
        {
            Entities1 dbeadd = new Entities1();
            string manhanvien = txtMaNV.Text;
            NHANVIEN NV = dbeadd.NHANVIENs.Where(nv => nv.MaNV == manhanvien).SingleOrDefault();
            if (NV == null)
            {
                NHANVIEN item = new NHANVIEN();
                item.MaNV = manhanvien;
                item.HoTen = txtHoTen.Text;
                item.NgaySinh = DTPNgaySinh.Value;
                item.DiaChi = txtDiaChi.Text;
                item.MaPB = ((PHONGBAN)CBPhongBan.SelectedValue).MaPB;
                item.MaCV = ((CHUC_VU)CBChucVu.SelectedValue).MaCV;
                dbeadd.NHANVIENs.Add(item);
                dbeadd.SaveChanges();
                LoadData();
            }
            else
            {
                MessageBox.Show("Vui lòng kiểm tra lại Mã nhân viên", "Lỗi");
            }
        }

        private void btnDelete1_Click(object sender, EventArgs e)
        {
            Entities1 dbedelete = new Entities1();
            string manhanvien = txtMaNV.Text;
            NHANVIEN NV = dbedelete.NHANVIENs.Where(nv => nv.MaNV == manhanvien && nv.HoTen == txtHoTen.Text).SingleOrDefault();
            if (NV != null)
            {
                dbedelete.NHANVIENs.Remove(NV);
                dbedelete.SaveChanges();
                LoadData();
            }
            else
            {
                MessageBox.Show("Vui lòng kiểm tra lại Mã Nhân Viên và Họ Tên", "Lỗi");
            }
        }

        private void btnEdit1_Click(object sender, EventArgs e)
        {
            Entities1 dbeEdit = new Entities1();
            string manhanvien = txtMaNV.Text;
            NHANVIEN NV = dbeEdit.NHANVIENs.Where(nv => nv.MaNV == manhanvien).SingleOrDefault();
            if (NV != null)
            {
                NV.HoTen = txtHoTen.Text;
                NV.NgaySinh = DTPNgaySinh.Value;
                NV.DiaChi = txtDiaChi.Text;
                NV.MaPB = ((PHONGBAN)CBPhongBan.SelectedValue).MaPB;
                NV.MaCV = ((CHUC_VU)CBChucVu.SelectedValue).MaCV;
                dbeEdit.SaveChanges();
                LoadData();
            }
            else
            {
                MessageBox.Show("Vui lòng kiểm tra lại Mã Nhân Viên và Họ Tên", "Lỗi");
            }
        }

        private void btnPhongBan_Click(object sender, EventArgs e)
        {
            Form2 pb = new Form2(this);
            pb.Show();
            this.Hide();
        }

        private void btnChucVu_Click(object sender, EventArgs e)
        {
            Form3 pb1 = new Form3(this);
            pb1.Show();
            this.Hide();
        }
    }
}
