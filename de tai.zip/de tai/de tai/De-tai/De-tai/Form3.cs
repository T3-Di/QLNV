﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace De_tai
{
    public partial class Form3 : Form
    {
        Form1 mn;
        Entities1 dbe = new Entities1();
        public Form3()
        {
            InitializeComponent();
        }
        public Form3(Form1 mn)
        {
            InitializeComponent();
            this.mn = mn;
            LoadData();
        }
        void LoadData()
        {
            DGVChucVu.AutoGenerateColumns = false;
            DGVChucVu.DataSource = dbe.CHUC_VU.ToList();
            txtMaCV.DataBindings.Clear();
            txtMaCV.DataBindings.Add(new Binding("Text", DGVChucVu.DataSource, "MaCV"));
            txtTenCV.DataBindings.Clear();
            txtTenCV.DataBindings.Add(new Binding("Text", DGVChucVu.DataSource, "TenCV"));
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.mn.Show();
            this.Hide();
        }

        private void btnAdd3_Click(object sender, EventArgs e)
        {
            Entities1 dbeAdd = new Entities1();
            string machucvu = txtMaCV.Text;
            CHUC_VU pb = dbeAdd.CHUC_VU.Where(p => p.MaCV == machucvu).SingleOrDefault();
            if (pb != null)
            {
                CHUC_VU item = new CHUC_VU();
                item.MaCV = machucvu;
                item.TenCV = txtTenCV.Text;
                dbeAdd.CHUC_VU.Add(item);
                dbeAdd.SaveChanges();
                LoadData();
            }
            else
            {
                MessageBox.Show("Vui lòng kiểm tra lại mã chức vụ", "Lỗi");
            }
        }

        private void btnDelete3_Click(object sender, EventArgs e)
        {
            string machucvu = txtMaCV.Text;
            CHUC_VU pb = dbe.CHUC_VU.Where(p => p.MaCV == machucvu).SingleOrDefault();
            if (pb != null)
            {
                if (pb.NHANVIENs.Count > 0)
                {
                    MessageBox.Show("Hãy đổi Chức vụ phòng ban này", "Lỗi");
                }
                else
                {
                    dbe.CHUC_VU.Remove(pb);
                    dbe.SaveChanges();
                    LoadData();
                }
            }
            else
            {
                MessageBox.Show("Vui lòng kiểm tra lại mã chức vụ", "Lỗi");
            }
        }

        private void btnEdit3_Click(object sender, EventArgs e)
        {
            string machucvu = txtMaCV.Text;
            CHUC_VU pb = dbe.CHUC_VU.Where(p => p.MaCV == machucvu).SingleOrDefault();
            if (pb != null)
            {
                if (pb.NHANVIENs.Count > 0)
                {
                    foreach (NHANVIEN nv in pb.NHANVIENs)
                    {
                        nv.MaCV = machucvu;
                    }
                }
                pb.MaCV = machucvu;
                pb.TenCV = txtTenCV.Text;
                dbe.SaveChanges();
                LoadData();
            }
            else
            {
                MessageBox.Show("Vui lòng kiểm tra lại mã chức vụ", "Lỗi");
            }
        }
    }
}
