﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace De_tai
{
    public partial class Form2 : Form
    {
        Form1 mn;
        Entities1 dbe = new Entities1();
        public Form2()
        {
            InitializeComponent();
        }
        public Form2(Form1 mn)
        {
            InitializeComponent();
            this.mn = mn;
            LoadData();
        }
        void LoadData()
        {
            DGVPhongBan.AutoGenerateColumns = false;
            DGVPhongBan.DataSource = dbe.PHONGBANs.ToList();
            txtMaPB.DataBindings.Clear();
            txtMaPB.DataBindings.Add(new Binding("Text", DGVPhongBan.DataSource, "MaPB"));
            txtTenPB.DataBindings.Clear();
            txtTenPB.DataBindings.Add(new Binding("Text", DGVPhongBan.DataSource, "TenPB"));
        }
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.mn.Show();
            this.Hide();
        }

        private void btnAdd2_Click(object sender, EventArgs e)
        {
            Entities1 dbeAdd = new Entities1();
            string maphongban = txtMaPB.Text;
            PHONGBAN pb = dbeAdd.PHONGBANs.Where(p => p.MaPB == maphongban).SingleOrDefault();
            if (pb != null)
            {
                PHONGBAN item = new PHONGBAN();
                item.MaPB = maphongban;
                item.TenPB = txtTenPB.Text;
                dbeAdd.PHONGBANs.Add(item);
                dbeAdd.SaveChanges();
                LoadData();
            }
            else
            {
                MessageBox.Show("Vui lòng kiểm tra lại mã nhân viên", "Lỗi");
            }
        }

        private void btnDelete2_Click(object sender, EventArgs e)
        {
            string maphongban = txtMaPB.Text;
            PHONGBAN pb = dbe.PHONGBANs.Where(p => p.MaPB == maphongban).SingleOrDefault();
            if (pb != null)
            {
                if (pb.NHANVIENs.Count > 0)
                {
                    MessageBox.Show("Hãy đổi Nhân Viên phòng ban này", "Lỗi");
                }
                else
                {
                    dbe.PHONGBANs.Remove(pb);
                    dbe.SaveChanges();
                    LoadData();
                }
            }
            else
            {
                MessageBox.Show("Vui lòng kiểm tra lại mã nhân viên", "Lỗi");
            }
        }

        private void btnEdit2_Click(object sender, EventArgs e)
        {
            string maphongban = txtMaPB.Text;
            PHONGBAN pb = dbe.PHONGBANs.Where(p => p.MaPB == maphongban).SingleOrDefault();
            if (pb != null)
            {
                if (pb.NHANVIENs.Count > 0)
                {
                    foreach (NHANVIEN nv in pb.NHANVIENs)
                    {
                        nv.MaPB = maphongban;
                    }
                }
                pb.MaPB = maphongban;
                pb.TenPB = txtTenPB.Text;
                dbe.SaveChanges();
                LoadData();
            }
            else
            {
                MessageBox.Show("Vui lòng kiểm tra lại mã nhân viên", "Lỗi");
            }
        }


    }
}
